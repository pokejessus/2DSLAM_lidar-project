from RRT_base import RRT, RRTGraphics

import pygame
import time

# Visualization parameters
MapW, MapH = 1200, 600
MapDimensions=(MapH, MapW)
start = (50, 50)
goal = (510, 510) 

# Setup window and screen
pygame.display.set_caption('RRT')
screen = pygame.display.set_mode((MapW, MapH))
screen.fill((255,255,255))

# Map 
mapImg_path = 'map1.png'
roomMap = pygame.image.load(mapImg_path)
screen.blit(roomMap, (0,0))

# RRT
rrt_path = RRT(start, goal, MapDimensions, roomMap)
rrt_Graphics = RRTGraphics(rrt_path, screen, MapDimensions)

iteration = 0

while not rrt_path.path_to_goal():
    print(f"Iteration {iteration}", " ")
    rrt_path.run_RRT(iteration)

    screen.fill((255,255,255))
    screen.blit(roomMap, (0,0))

    rrt_Graphics.updateRRTGraphics()
    # print(f"nb of nodes {len(rrt_path.x)}  nb of parents {len(rrt_path.parents)}")

    pygame.display.update()
    # time.sleep(0.1)
    iteration += 1

rrt_Graphics.drawPath()
pygame.display.update()
pygame.event.clear()
pygame.event.wait(0)