import math
import numpy as np
from env_lidar import Fakelidar, check_collision_test, display_points, display_clusters_image, display_clusters_scatter
from collections import deque

def point_to_line_distance(p, a, b):
    """
    Calculates the intersection point and the shortest distance 
    between point P and the line segment formed by A and B.
    """
    # 1. Extract coordinates (using index 3 and 4 for x, y from your lidar tuple)
    px, py = p[0], p[1]
    ax, ay = a[0], a[1]
    bx, by = b[0], b[1]


    # Find the function (slope and intercept) for line AB
    # Line: y = mx + c
    if bx - ax == 0:  # Vertical line case
        intersect_x = ax
        intersect_y = py
    elif by - ay == 0:  # Horizontal line case
        intersect_x = px
        intersect_y = ay
    else:
        # Slope of AB (m1)
        m1 = (by - ay) / (bx - ax)
        # Y-intercept of AB (c1 = y - mx)
        c1 = ay - m1 * ax

        # 2. Find the perpendicular function passing through P
        # Perpendicular slope (m2) is the negative reciprocal: -1/m1
        m2 = -1 / m1
        # Y-intercept of perpendicular line (c2 = y - mx)
        c2 = py - m2 * px

        # 3. Find the intersection point (cross point)
        # Set equations equal: m1*x + c1 = m2*x + c2
        # x(m1 - m2) = c2 - c1
        intersect_x = (c2 - c1) / (m1 - m2)
        intersect_y = m1 * intersect_x + c1


    max_x = max([ax, bx])
    min_x = min([ax, bx])
    max_y = max([ay, by])
    min_y = min([ay, by])

    if (min_x < intersect_x < max_x and min_y < intersect_y < max_y):
        distance = math.sqrt((px - intersect_x)**2 + (py - intersect_y)**2)

    else:
        distance = min([math.sqrt((px - ax)**2 + (py - ay)**2), math.sqrt((px - bx)**2 + (py - by)**2)])

    return distance



if __name__ == "__main__":
    p = (713.6, 343.1)
    a = (680, 260)
    b = (586.2, 95.7)

    print(point_to_line_distance(p, a, b))