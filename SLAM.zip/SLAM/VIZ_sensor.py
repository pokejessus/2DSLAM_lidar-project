from us_sensor import US_sensor
import math
import pygame

# Visualization parameters
MapW, MapH = 1200, 600
MapDimensions=(MapH, MapW)                   

# Setup window and screen
pygame.display.set_caption('Sensors')
screen = pygame.display.set_mode((MapW, MapH))
screen.fill((0,0,0))

# Map 
mapImg_path = 'map1.png'
roomMap = pygame.image.load(mapImg_path)
screen.blit(roomMap, (0,0))
screen.fill((0,0,0))

# Sensors
us_east = US_sensor(0, roomMap, screen)
us_north= US_sensor(90, roomMap, screen)
us_west = US_sensor(180, roomMap, screen)
us_south = US_sensor(270, roomMap, screen)
sensors = [us_east, us_north, us_west, us_south]

running = True
while running:
    sensorON = False
    # Stop upon x press
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if pygame.mouse.get_focused():
        sensorON = True
    elif not pygame.mouse.get_focused():
        sensorON = False

    if sensorON:
        screen.fill((0,0,0))
        position = pygame.mouse.get_pos()

        for sensor in sensors:
            sensor.x, sensor.y = position
            us_data, sensor_lines = sensor.sense_obstacles()
            sensor.dataStorage(us_data)
            sensor.draw_sensors_and_data(sensor_lines)

    pygame.display.update()