from us_sensor import US_sensor
from robotDDR import Robot, robotGaphics
import math
import pygame

# Visualization parameters
MapW, MapH = 1200, 600
MapDimensions=(MapH, MapW)             
start = (50, 50)
clock = pygame.time.Clock()     # timing for robot movement
dt = 0         

# Setup window and screen
pygame.display.set_caption('Sensors')
screen = pygame.display.set_mode((MapW, MapH))
screen.fill((0,0,0))

# Map 
mapImg_path = 'map1.png'
roomMap = pygame.image.load(mapImg_path)
screen.blit(roomMap, (0,0))
print(f"Map Size {roomMap.get_size()}")
# Sensors
us_east = US_sensor(0, roomMap, screen, (start[0]+22, start[1]))
us_north= US_sensor(90, roomMap, screen, (start[0], start[1]-22))
us_west = US_sensor(180, roomMap, screen, (start[0]-22, start[1]))
us_south = US_sensor(270, roomMap, screen, (start[0], start[1]+22))
sensors = [us_east, us_north, us_west, us_south]

# Robot
robot = Robot(start, sensors)
RobotGraphics = robotGaphics(robot, screen, MapDimensions, robot_img_path='robot.png')

running = True
while running:
    # update time
    clock.tick_busy_loop(30)
    dt = (clock.get_time() - dt) / 1000
    
    # Stop upon x press
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # check for mouse click
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                robot.path.append(event.pos)
                print(f"Left mouse button clicked at position: {event.pos}")

    # screen.fill((0,0,0))
    screen.fill((255,255,255))

    robot.moveRobot(dt)
    RobotGraphics.drawRobot()
    RobotGraphics.updateRobot()

    for sensor in sensors:
        us_data, sensor_lines = sensor.sense_obstacles()
        sensor.dataStorage(us_data)
        sensor.draw_sensors_and_data(sensor_lines)

    pygame.display.update()