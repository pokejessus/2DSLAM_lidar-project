from particle_filter import ParticleFilter      
from us_sensor import US_sensor
from robotDDR import Robot, robotGaphics
import math
import pygame
import numpy as np

# Visualization parameters
MapW, MapH = 1200, 600
MapDimensions=(MapH, MapW)
start = (500, 350)
clock = pygame.time.Clock()     # timing for robot movement
dt = 0         

# Setup window and screen
pygame.display.set_caption('Sensors')
screen = pygame.display.set_mode((MapW, MapH))
screen.fill((0,0,0))

# Map 
mapImg_path = 'map1.png'
roomMap = pygame.image.load(mapImg_path)
screen.blit(roomMap, (0,0))
# print(f"Map Size {roomMap.get_size()}")

# Sensors
us_east = US_sensor(0, roomMap, screen, (start[0]+22, start[1]))
us_north= US_sensor(90, roomMap, screen, (start[0], start[1]-22))
us_west = US_sensor(180, roomMap, screen, (start[0]-22, start[1]))
us_south = US_sensor(270, roomMap, screen, (start[0], start[1]+22))
sensors = [us_east, us_north, us_west, us_south]

# Robot
robot = Robot(start, sensors)
RobotGraphics = robotGaphics(robot, screen, MapDimensions, robot_img_path='robot.png')

# Particle Filter
NUMPARTICLES = 800
pf = ParticleFilter(roomMap, sensors, NUMPARTICLES, (start[0], start[1], 0))

counter = 0
running = True
while running:
    # update time
    clock.tick_busy_loop(30)
    dt = (clock.get_time() - dt) / 1000
    
    # Stop upon x press
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # check for mouse click
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                robot.path.append(event.pos)
                # print(f"Left mouse button clicked at position: {event.pos}")

    # screen.fill((0,0,0))
    screen.fill((255,255,255))
    # screen.blit(roomMap, (0,0))

    # =============== Simulation Execution ========================

    # Move robot
    robot.moveRobot(dt)
    # draw robot
    RobotGraphics.drawRobot()
    RobotGraphics.updateRobot()

    # Predict particle filter
    pf.predict(robot.u, robot.w, dt)

    # Gather robot sensor data
    robot_us_data = []
    for sensor in sensors:
        us_data, sensor_lines = sensor.sense_obstacles()
        if type(us_data) == int:
            robot_us_data.append(us_data)
        else:
            robot_us_data.append(us_data[0])
        # draw sensor lines and measurements
        sensor.dataStorage(us_data)
        sensor.draw_sensors_and_data(sensor_lines)

    # In VIZ_particles.py, after robot_us_data is gathered:
    # if len(robot_us_data) > 0:
        # print(f"Robot sensor readings: {robot_us_data}")
    # Update and Resample particles
    pf.update(robot_us_data)
    # After pf.update():
    if len(pf.particles) > 0:
        # Get measurements for particle nearest to robot
        nearest_idx = np.argmin(np.linalg.norm(
            pf.particles[:, :2] - [robot.x, robot.y], axis=1
        ))
        p_sensors = pf.set_sensors_on_particle(nearest_idx)
        p_measurements = [pf.simulate_sensor(sx, sy, st) for sx, sy, st in p_sensors]
        # print(f"Nearest particle measurements: {p_measurements}")

    pf.resample()
    # draw estimated position
    estimate_x, estimate_y, estimate_theta = pf.estimated_position
    pygame.draw.circle(screen, (255,0,255), (int(estimate_x), int(estimate_y)), 10, 0)
    pygame.draw.line(screen, (0,0,0), (estimate_x, estimate_y), (estimate_x + 12*math.cos(estimate_theta), estimate_y + 12*math.sin(estimate_theta)), 1)
    # draw particles with their direction
    for px, py, ptheta in pf.particles:
        pygame.draw.circle(screen, (0,0,255), (px, py), 2)
        pygame.draw.line(screen, (0,0,0), (px, py), (px + 6*math.cos(ptheta), py + 6*math.sin(ptheta)), 1)
    # draw estimated path
    for i in range(0, len(pf.estimated_path)-1):
        pygame.draw.line(screen, (0,0,255), (pf.estimated_path[i][0], pf.estimated_path[i][1]),
                             (pf.estimated_path[i+1][0], pf.estimated_path[i+1][1]), 2)
        if len(pf.estimated_path) > 10000:
            pf.estimated_path.pop(0)

    if counter % 50 == 0:
        print(f"Distance between robot and estimation {robot.distance((robot.x, robot.y), (estimate_x, estimate_y))}")
    counter += 1

    pygame.display.update()

    