import pygame
import math
import numpy as np
import random

"""
SIMULATING the HC-SR04 Ultrasonic Sensor
- angular spread (beam width),
- measurement noise model (mixture model: gaussian around true range + outlier terms)
"""


class US_sensor:
    def __init__(self, heading, map, screen, position=(0,0)):    
        # ======== HC-SR04 CONSTANTS (from datasheet) ==========
        # self.minRange = 2                         # 2cm ignore minRange for now
        self.maxRange = 150                          # 4m 
        self.accuracy = 1                           # 3mm, closest approximation is 1 pixel (1cm)
        self.measure_angle = math.radians(10)       # MeasuringAngle = 15 degrees but middle receives stronger pulses

        # Calculation Variables 
        self.position = position
        self.x, self.y = position
        self.map_w, self.map_h = pygame.display.get_surface().get_size()
        self.heading = math.radians(heading)


        # ============== Graphics ==================
        pygame.init()
        self.pointCloud = []
 
        # Colors
        self.Black = (0,0,0)
        self.Red = (255,0,0)
        self.Green = (0,255,0)
        self.Blue = (0,0,255)
        self.White = (255,255,255)
        self.lineColor = (0, 208, 255)
    
        self.screen = screen
        self.map = map

    def sense_obstacles(self, add_noise=True, resolution=20):
        data = []
        sensor_lines = []
        start_angle = self.heading - self.measure_angle
        finish_angle = self.heading + self.measure_angle
        # Scan cone
        for angle in np.linspace(start_angle, finish_angle, resolution, False):
            # Get coordinate of farthest point
            x2 = self.x + self.maxRange * math.cos(angle)
            y2 = self.y - self.maxRange * math.sin(angle)
            # Find obstacle on line
            for i in range(0,100):
                u = i / 99
                # interpolation
                x = int(x2 * u + self.x * (1-u))
                y = int(y2 * u + self.y * (1-u))
                # if point in the map
                if 0 < x < self.map_w and 0 < y < self.map_h:
                    # color sensor lines
                    color = self.map.get_at((x, y))
                    sensor_lines.append((x,y))
                    # obstacle detected
                    if (color[0], color[1], color[2]) == (0, 0, 0):
                        distance = self.distance((x, y))
                        if add_noise:
                            distance = self.add_uncertainty(distance)
                        output = [distance, (self.x, self.y), self.heading]
                        data.append(output)
                        break
        # get closest measurement from cone
        shortest_output = [0,0]
        for i, (d, _, _) in enumerate(data):
            if d > shortest_output[0]:
                shortest_output[0] = d
                shortest_output[1] = i
        if not data:
            return self.maxRange, sensor_lines
        # print(f"Data: {data[i]}")
        return data[i], sensor_lines


    def distance(self, obstaclePos):
        px = (obstaclePos[0]-self.x)**2
        py = (obstaclePos[1]-self.y)**2
        return math.sqrt(px + py)
    
    def add_uncertainty(self, distance):
        # Noise in HC-SR04 is generally non-gaussian
        noise = random.uniform(-self.accuracy, self.accuracy)
        return distance + noise
    

    # ===================== Graphics =====================
    
    def AD2pos(self, distance, sensorPos, heading):
        x = distance * math.cos(heading) + sensorPos[0]
        y = -distance * math.sin(heading) + sensorPos[1]
        return (int(x), int(y))
    
    def dataStorage(self, output):
        if output == self.maxRange:
            return
        point = self.AD2pos(output[0], output[1], output[2])
        if point not in self.pointCloud:
            self.pointCloud.append(point)

    def draw_sensors_and_data(self, sensor_lines):
        for sensor_p in sensor_lines:
            # pygame.draw.line(self.screen, self.lineColor, self.position, (sensor_p[0], sensor_p[1]), 1)
            self.screen.set_at((sensor_p[0], sensor_p[1]), self.lineColor)
        for point in self.pointCloud:
            pygame.draw.circle(self.screen, (255,0,0), (point[0], point[1]), 1,)
            # self.screen.set_at((point[0], point[1]), (255, 0, 0))