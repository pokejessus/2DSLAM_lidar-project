import numpy as np
import math
import pygame
import random

# offset of sensors from the center of the robot/particles
R_OFF = 22

class ParticleFilter:
    def __init__(self, map, sensors, num_particles, initial_pos):
        self.num_particles = num_particles
        self.particles = np.empty((num_particles, 3))       # Each particle has x, y, theta
        self.weights = np.ones(self.num_particles) / self.num_particles

        self.initialize_particles(initial_pos)
        self.estimated_path = [initial_pos[:2]]
        self.estimated_position = initial_pos[:2]

        # map
        self.map = map
        self.mapW, self.mapH = map.get_size()
        self.mapGrid = self.make_map_grid()
        print(f"Map dimensions mapGrid[0] {len(self.mapGrid[0])} mapGrid {len(self.mapGrid)}")

        # sensors
        self.sensors = sensors
        # relative x, y, theta of the four sensors
        self.sensor_offsets = np.array([[R_OFF, 0, 0],                  # east
                                        [0, -R_OFF, math.pi / 2],       # north
                                        [-R_OFF, 0, math.pi],           # west
                                        [0, R_OFF, 3*math.pi / 2]])     # south
        

    def initialize_particles(self, initial_pos):
        self.particles[:, 0] = initial_pos[0] + np.random.randn(self.num_particles) * 100   # x
        self.particles[:, 1] = initial_pos[1] + np.random.randn(self.num_particles) * 100   # y
        self.particles[:, 2] = initial_pos[2] + np.random.randn(self.num_particles) * 0.5   # theta

    # move particles based on speed of robot movement
    def predict(self, v, omega, dt):
        noise_std = [0.05, 0.05, 0.01]
        self.particles[:, 0] += ( (v * np.cos(self.particles[:, 2]) * dt) + 
                                 np.random.randn(self.num_particles) * noise_std[0] )
        self.particles[:, 1] += ( (v * np.sin(self.particles[:, 2]) * dt) + 
                                 np.random.randn(self.num_particles) * noise_std[1] )
        self.particles[:, 2] += (omega * dt + np.random.randn(self.num_particles) * noise_std[2])
        # self.particles[:, 2] = np.arctan2(
        #     np.sin(self.particles[:, 2]),
        #     np.cos(self.particles[:, 2])
        # )

    def make_map_grid(self):
        # get pixel array of map with shape [width, height]
        px_arr = pygame.surfarray.array2d(self.map)
        # 1 if obstacle (black), 0 if free space (white)
        print(f"pixel format of map: {self.map.get_bitsize()}")
        print(px_arr[:,300])
        map_grid = np.where(px_arr == -1, 0, 1)
        return map_grid.T
    
    def simulate_sensor(self, x, y, theta, noise=1):
        sensor = self.sensors[0]

        # Get coordinate of farthest point
        x2 = x + sensor.maxRange * math.cos(theta)
        y2 = y - sensor.maxRange * math.sin(theta)
        # Find obstacle on line
        nb_steps = 30
        for i in range(0,nb_steps):
            u = i / (nb_steps-1)
            # interpolation
            check_x = int(x2 * u + x * (1-u))
            check_y = int(y2 * u + y * (1-u))
            # if point in the map
            if 0 <= check_x < self.mapW and 0 <= check_y < self.mapH:
                # obstacle detected
                # print(f"obstacle detected check_x {check_x} check_y {check_y}")
                if self.mapGrid[check_y, check_x] == 1:
                    eucl_dist = math.sqrt((x-check_x)**2 + (y-check_y)**2)
                    return eucl_dist + random.uniform(-noise, noise)
        return sensor.maxRange

    def set_sensors_on_particle(self, particle_ix):
        # particle position/heading
        px, py, ptheta = self.particles[particle_ix]
        # print(f'particle: {self.particles[particle_ix]}')

        # relative position/heading
        rel_x = self.sensor_offsets[:, 0]
        rel_y = self.sensor_offsets[:, 1]
        rel_theta = self.sensor_offsets[:, 2]

        # Rotate the relative position vector by the particle's current theta. Rotation matrix:
        # x' = x*cos(theta) - y*sin(theta)
        # y' = x*sin(theta) + y*cos(theta)
        sensor_rotation = np.zeros_like(self.sensor_offsets)
        sensor_rotation[:, 0] = rel_x * np.cos(ptheta) - rel_y * np.sin(ptheta)
        sensor_rotation[:, 1] = rel_x * np.sin(ptheta) + rel_y * np.cos(ptheta)

        # Add rotated vectors to particle's position
        sensor_positions = np.zeros_like(self.sensor_offsets)
        sensor_positions[:, 0] = px + sensor_rotation[:, 0]
        sensor_positions[:, 1] = py + sensor_rotation[:, 1]

        # Fix angle
        sensor_positions[:, 2] = rel_theta - ptheta 
        
        return sensor_positions

    def get_particle_measurements(self):
        particle_measurements = []
        for i, _ in enumerate(self.particles):
            particle_sensors = self.set_sensors_on_particle(i)
            measurements = []
            for (sx, sy, stheta) in particle_sensors:
                dist = self.simulate_sensor(sx, sy, stheta)
                measurements.append(dist)
            particle_measurements.append(measurements)
        return np.array(particle_measurements)

    # particles take sensor measurement and compare to how close they are to robot's
    def update(self, robot_measurements):
        # simulate sensor measurement for particles
        particle_measurements = self.get_particle_measurements()

        # calculate weight based on measurement similarity
        diff = particle_measurements - robot_measurements
        mse = np.mean( diff**2, axis=1)

        # Add sigma to broaden tolerance
        sigma = 30
        # # Calculate weight per sensor
        # sensor_weights = np.exp(-diff**2 / (2 * sigma**2))
        # # MULTIPLY weights across sensors (all 4 must match)
        # self.weights = np.prod(sensor_weights, axis=1)
        
        # Adjust weights
        self.weights = np.exp( -mse / (2 * sigma**2) )
        self.weights += 1e-20               # avoid zeros
        self.weights /= sum(self.weights)   # normalize

    # keep particles closest to sensor readings
    def resample(self):
        indices = np.random.choice(self.num_particles, self.num_particles, p=self.weights)      # choose particles randomly, but more chance to get ones with high weight
        self.particles = self.particles[indices]
        self.weights = np.ones(self.num_particles) / self.num_particles     # reset weights

        # estimate position
        x_estimate = np.mean(self.particles[:, 0])
        y_estimate = np.mean(self.particles[:, 1])
        theta_estimate = np.mean(self.particles[:, 2])
        # print(f"resample(): x_estim {x_estimate} y_estim {y_estimate} theta_estim {theta_estimate}")

        self.estimated_position = (x_estimate, y_estimate, theta_estimate)
        self.estimated_path.append(self.estimated_position[:2])
