from robotDDR import Robot, robotGaphics
import math
import pygame

# Visualization parameters
MapW, MapH = 1200, 600
MapDimensions=(MapH, MapW)
start = (50, 50)
clock = pygame.time.Clock()     # timing for robot movement
dt = 0                          

# Setup window and screen
pygame.display.set_caption('DDR Robot')
screen = pygame.display.set_mode((MapW, MapH))
screen.fill((0,0,0))

# Robot
robot = Robot(start)
RobotGraphics = robotGaphics(robot, screen, MapDimensions, robot_img_path='robot.png')

running = True
while running: 
    # update time
    clock.tick_busy_loop(30)
    dt = (clock.get_time() - dt) / 1000

    # Stop upon x press
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # check for mouse click
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                robot.path.append(event.pos)
                print(f"Left mouse button clicked at position: {event.pos}")

    screen.fill((0,0,0))
    # robot.update_robotPos(dt)
    robot.moveRobot(dt)
    RobotGraphics.drawRobot()
    RobotGraphics.updateRobot()

    pygame.display.update()